import { Data, animate, Override, Animatable } from 'framer'

const data = Data({ hangerTop: Animatable(675), hangerWidth: Animatable(345) })

export const Hanger: Override = () => {
  return {
    top: data.hangerTop,
    width: data.hangerWidth,
  }
}

export const DragCloseBar: Override = props => {
  return {
    //   visible: playBar.overlayVisible,
    //   playBar: playBar,
    //   closePlayerByDrag: closePlayerByDrag,
    hangerTop: data.hangerTop,
    hangerWidth: data.hangerWidth,
  }
}
